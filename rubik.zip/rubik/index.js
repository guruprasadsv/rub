const express = require('express');
const translate = require('google-translate-api');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io').listen(server);
const bodyParser = require('body-parser');
const testing = require('testing');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


var usernames = [];
server.listen(process.env.PORT|| 3000);
console.log('Server Running..');

app.get('/', (req, res) => {
	res.sendFile(__dirname = '/Users/admin/rubik/index.html');
})
app.get('/RanNum', (req, res) => {
	res.sendFile(__dirname = '/Users/admin/rubik/random.html');
})
app.post('/RanNum',(req, res) => {
	var input = req.body.answer;
	var x = Math.random();
	var y = '';
	if (input == "test1" ) {
	if (x < 0.333) {
	y= 'Output: 0';
	} else {
	y= 'Output: 1';
	}
	}
	if (input == "test2" ) {
	var m = Math.floor(Math.random() * 4) ;
	y = "Output: " + m;
	}
	if (input == "test3" ) {
	if (x<0.5) {
	y='Output: 0';
	} else {
	y='Output: 2';
	}
	}

	res.send(y);
});
io.sockets.on('connection', function(socket){
	console.log('Socket Connected...');

socket.on('new user', function(data, callback){
	 if(usernames.indexOf(data) != -1){
		 callback(false);
	 } else {
		 callback(true);
		 socket.username = data;
		 usernames.push(socket.username);
		 updateUsernames();
	 }
});
// Update usernames
function updateUsernames(){
	io.sockets.emit('usernames', usernames);
}

	// Send Message
	socket.on('send message', function(data){
		io.sockets.emit('new message', {msg: data, user:socket.username});
	});

	socket.on('disconnect', function(data){
		if(!socket.username){
			return;
		}
		usernames.splice(usernames.indexOf(socket.username),1);
		updateUsernames();
	});

});

//Disconnet

app.get('/about', (req, res) => {
	res.send('About page. Nice.')
})
// app.listen(3000, () => console.log('listening on port 3000'))
